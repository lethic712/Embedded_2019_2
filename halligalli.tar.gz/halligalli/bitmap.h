#ifndef _BITMAP_H_
#define _BITMAP_H_

int jpegInit (void);
int jpegExit (void);
int jpegWrite (int ic);

#endif
