#ifndef _BUTTON_H_
#define _BUTTON_H_

#define BUTTON_DRIVER_NAME "/dev/input/event5"
#define MESSAGE_ID 1122

int buttonLibInit(void);
int buttonLibExit(void);

typedef struct
{
	long int messageNum;
	int keyInput;
	int touch[2];
	int whoSend;
} BUTTON_MSG_T;

#endif// _BUTTON_H_
