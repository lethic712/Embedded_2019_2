#include <fcntl.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <linux/input.h>
#include <unistd.h>
#include "touch.h"
#include "button.h"

static pthread_t touchTh_id;
static pthread_t timerTh_id;
static pthread_t filteringTh_id;

static int fd = 0;
static void* touchThFunc(void* arg);
static void* timerThFunc(void* arg);
static void* filteringThFunc(void* arg);

static int msgID = 0;
static int msgBodyID = 0;

int touchLibInit(void)
{
	fd = open (EVENT_DEVICE, O_RDONLY);
	msgID = msgget((key_t)TOUCH_MESSAGE_ID, IPC_CREAT | 0666);	
	msgBodyID = msgget((key_t)MESSAGE_ID, IPC_CREAT | 0666);		
	pthread_create(&touchTh_id, NULL, &touchThFunc, NULL);
	pthread_create(&timerTh_id, NULL, &timerThFunc, NULL);
	pthread_create(&filteringTh_id, NULL, &filteringThFunc, NULL);
}

static void* filteringThFunc(void* arg)
{
	int x;
	int y;
	int cnt=0;
	BUTTON_MSG_T internalRx;
	while (1)
	{
		//msgrcv(ButtonMsgID, &msgRx, sizeof(BUTTON_MSG_T)-sizeof(long int), 0, 0);
		msgrcv(msgID, &internalRx, sizeof(BUTTON_MSG_T)-sizeof(long int), 0, 0);
		if (internalRx.whoSend == 2) 
		{
			x = internalRx.touch[0];
			cnt=0;
		}
		else if (internalRx.whoSend == 3) 
		{
			y=internalRx.touch[1];
			cnt = 0;
		}
		else if (internalRx.whoSend == 1) 
		{
			cnt++;
			if (cnt == 5)	//500ms.
			{
				printf ("SEnd X=Y: %d,%d\r\n",x,y);
				BUTTON_MSG_T touchTx;
				touchTx.messageNum = 1;
				touchTx.whoSend = 100;
				touchTx.touch[0] = x;
				touchTx.touch[1] = y;
				msgsnd(msgBodyID, &touchTx, sizeof(BUTTON_MSG_T)-sizeof(long int), 0);
				cnt = 6;
			}
		}
	}
}

int touchLibExit(void)
{
	pthread_cancel(touchTh_id);
	pthread_cancel(timerTh_id);
}

static void* timerThFunc(void* arg)
{
	BUTTON_MSG_T timerTx;
	timerTx.messageNum = 1;
	timerTx.touch[0] = 0;
	timerTx.touch[1] = 0;
	timerTx.whoSend = 1;
	
	while(1)
	{
		usleep(1000*100); // 0.1초
		msgsnd(msgID, &timerTx, sizeof(BUTTON_MSG_T)-sizeof(long int), 0);
	}
}

static void* touchThFunc(void* arg)
{
	BUTTON_MSG_T touchTx;
	touchTx.messageNum = 1;
	
	
	struct input_event touchEvent;
	
	while (1)
	{
		read(fd, &touchEvent, sizeof(touchEvent));
		
		if (touchEvent.type == EV_ABS && (touchEvent.code == ABS_X || touchEvent.code == ABS_Y)) 
		{
			if(touchEvent.code == ABS_X)
			{ 
				touchTx.whoSend = 2; 
				touchTx.touch[0]= touchEvent.value;
			 }
			else if (touchEvent.code == ABS_Y)
			{  
				touchTx.whoSend = 3;
				touchTx.touch[1]= touchEvent.value;
			}
		}
		
		msgsnd(msgID, &touchTx, sizeof(BUTTON_MSG_T)-sizeof(long int), 0);
	}
}
