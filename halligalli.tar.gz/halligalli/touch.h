#ifndef _TOUCH_H_
#define _TOUCH_H_

#define EVENT_DEVICE "/dev/input/event4"
#define MESSAGE_ID 1122
#define TOUCH_MESSAGE_ID 1123

int touchLibInit(void);
int touchLibExit(void);


#endif// _TOUCH_H_
